-- phpMyAdmin SQL Dump
-- version 4.9.7deb1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 13-01-2022 a las 14:15:51
-- Versión del servidor: 8.0.27-0ubuntu0.21.04.1
-- Versión de PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `erp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `branches`
--

CREATE TABLE `branches` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut_manager` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category_products`
--

CREATE TABLE `category_products` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `companies`
--

CREATE TABLE `companies` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcountry` bigint UNSIGNED NOT NULL,
  `iddistrict` bigint UNSIGNED DEFAULT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_rut` int NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `companies`
--

INSERT INTO `companies` (`id`, `name`, `address`, `email`, `phone`, `rut`, `idcountry`, `iddistrict`, `admin_name`, `admin_rut`, `avatar`, `description`, `state`) VALUES
(1, 'Softnet SPA', 'Av. del Parque #5275, Oficina 103', 'softnetspa@softnet.cl', '56229479389', '76017114-K', 1, NULL, 'Felipe Videla Loewe', 0, NULL, 'Equipo de Softnet SPA', 1),
(2, 'Innapsis SAS SAC', 'Av. del Prado #535, Oficina 1033', 'innapsissas@innapsis.pe', '510181264721', '2012491241', 2, NULL, 'Lincoln Moreno Garcilazo', 0, NULL, 'Equipo de Desarrollo de Innapsis SAS', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contracts`
--

CREATE TABLE `contracts` (
  `id` bigint UNSIGNED NOT NULL,
  `idemployee` bigint UNSIGNED NOT NULL,
  `type_contract` bigint UNSIGNED NOT NULL,
  `n_cargas` int NOT NULL,
  `start_date` datetime NOT NULL,
  `finish_date` datetime NOT NULL,
  `salary` double NOT NULL,
  `type_gratification` int NOT NULL,
  `AFP` int NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contract_type`
--

CREATE TABLE `contract_type` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `countries`
--

CREATE TABLE `countries` (
  `id` bigint UNSIGNED NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idmoney` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `countries`
--

INSERT INTO `countries` (`id`, `country`, `idmoney`, `state`) VALUES
(1, 'Chile', 1, 1),
(2, 'Perú', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customers`
--

CREATE TABLE `customers` (
  `id` bigint UNSIGNED NOT NULL,
  `rut` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idperson` bigint UNSIGNED NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detail_employee_user`
--

CREATE TABLE `detail_employee_user` (
  `id` bigint UNSIGNED NOT NULL,
  `idemployee` bigint UNSIGNED NOT NULL,
  `iduser` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detail_modules`
--

CREATE TABLE `detail_modules` (
  `id` bigint UNSIGNED NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `idmodules` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detail_money`
--

CREATE TABLE `detail_money` (
  `id` bigint UNSIGNED NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `idmoney` bigint UNSIGNED NOT NULL,
  `idmoney_company` int NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detail_suppliers`
--

CREATE TABLE `detail_suppliers` (
  `id` bigint UNSIGNED NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `idsupplier` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `districts`
--

CREATE TABLE `districts` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idprovince` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employees`
--

CREATE TABLE `employees` (
  `id` bigint UNSIGNED NOT NULL,
  `rut` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut2` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_birth` datetime NOT NULL,
  `civil_status` int NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcountry` bigint UNSIGNED NOT NULL,
  `idcomuna` bigint UNSIGNED NOT NULL,
  `landline` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_employee` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employee_type`
--

CREATE TABLE `employee_type` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lots`
--

CREATE TABLE `lots` (
  `id` bigint UNSIGNED NOT NULL,
  `number` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skuproducto` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marks`
--

CREATE TABLE `marks` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_01_11_233350_create_money_table', 1),
(2, '2022_01_11_234712_create_countries_table', 1),
(3, '2022_01_11_235847_create_regions_table', 1),
(4, '2022_01_12_001632_create_provinces_table', 1),
(5, '2022_01_12_001955_create_districts_table', 1),
(6, '2022_01_12_002200_create_companies_table', 1),
(7, '2022_01_12_004118_create_branches_table', 1),
(8, '2022_01_12_004838_create_category_products_table', 1),
(9, '2022_01_12_005022_create_contract_types_table', 1),
(10, '2022_01_12_011538_create_employee_types_table', 1),
(11, '2022_01_12_012315_create_employees_table', 1),
(12, '2022_01_12_013150_create_contracts_table', 1),
(13, '2022_01_12_013624_create_person_types_table', 1),
(14, '2022_01_12_015453_create_customers_table', 1),
(15, '2022_01_12_020227_create_roles_table', 1),
(16, '2022_01_12_020908_create_users_table', 1),
(17, '2022_01_12_022252_create_detail_employee_users_table', 1),
(18, '2022_01_12_022425_create_plans_table', 1),
(19, '2022_01_12_022556_create_modules_table', 1),
(20, '2022_01_12_030627_create_detail_modules_table', 1),
(21, '2022_01_12_031208_create_detail_moneys_table', 1),
(22, '2022_01_12_031703_create_suppliers_table', 1),
(23, '2022_01_12_032208_create_detail_suppliers_table', 1),
(24, '2022_01_12_033013_create_lots_table', 1),
(25, '2022_01_12_033658_create_marks_table', 1),
(26, '2022_01_12_034537_create_payment_methods_table', 1),
(27, '2022_01_12_034659_create_products_table', 1),
(28, '2022_01_12_035333_create_sections_table', 1),
(29, '2022_01_12_035334_create_states_table', 1),
(30, '2022_01_12_035856_create_users_companies_table', 1),
(31, '2022_01_12_040029_create_warehouses_table', 1),
(32, '2022_01_12_040425_create_websockets_statistics_entries_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE `modules` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idPlan` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `modules`
--

INSERT INTO `modules` (`id`, `name`, `idPlan`, `state`) VALUES
(1, 'Inicio', 1, 1),
(2, 'Gestión comercial', 1, 1),
(3, 'Adquisiciones', 1, 1),
(4, 'Web', 1, 1),
(5, 'Contabilidad', 1, 1),
(6, 'Reportes', 1, 1),
(7, 'Scored clientes', 1, 1),
(8, 'POS', 1, 1),
(9, 'Woopy', 1, 1),
(10, 'Tributación', 1, 1),
(11, 'Tesorería', 1, 1),
(12, 'Inventario', 1, 1),
(13, 'COMEX', 1, 1),
(14, 'Remuneraciones', 1, 1),
(15, 'Gestión financiera', 1, 1),
(16, 'Presupuesto', 1, 1),
(17, 'Información financiera', 1, 1),
(18, 'Contratos', 1, 1),
(19, 'Capgemini', 1, 1),
(20, 'Desan', 1, 1),
(21, 'Módulo de producción', 1, 1),
(22, 'Módulo de cesión', 1, 1),
(23, 'Módulo contabilidad costos', 1, 1),
(24, 'Maquinarias y vehículos', 1, 1),
(25, 'Reloj control', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `money`
--

CREATE TABLE `money` (
  `id` bigint UNSIGNED NOT NULL,
  `money` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` datetime NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `money`
--

INSERT INTO `money` (`id`, `money`, `last_update`, `state`) VALUES
(1, 'pesos chilenos', '2021-11-21 18:22:59', 1),
(2, 'soles peruanos', '2021-11-21 18:22:59', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payment_method`
--

CREATE TABLE `payment_method` (
  `id` bigint UNSIGNED NOT NULL,
  `method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `person_type`
--

CREATE TABLE `person_type` (
  `id` bigint UNSIGNED NOT NULL,
  `kind` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan`
--

CREATE TABLE `plan` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `plan`
--

INSERT INTO `plan` (`id`, `name`, `state`) VALUES
(1, 'Movistar', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` bigint UNSIGNED NOT NULL,
  `sku` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku_supplier` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` int NOT NULL,
  `idmark` bigint UNSIGNED NOT NULL,
  `idcategory` bigint UNSIGNED NOT NULL,
  `idsupplier` bigint UNSIGNED NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provinces`
--

CREATE TABLE `provinces` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idregion` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regions`
--

CREATE TABLE `regions` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcountry` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modules_permissions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionsIds` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sections`
--

CREATE TABLE `sections` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `idmodules` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE `states` (
  `id` bigint UNSIGNED NOT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_state` int NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `states`
--

INSERT INTO `states` (`id`, `state`, `st_state`, `idcompany`) VALUES
(1, 'activo', 1, 1),
(2, 'inactivo', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint UNSIGNED NOT NULL,
  `rut` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idRole` bigint UNSIGNED NOT NULL,
  `avatar` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_companies`
--

CREATE TABLE `users_companies` (
  `id` bigint UNSIGNED NOT NULL,
  `idUser` bigint UNSIGNED NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `warehouses`
--

CREATE TABLE `warehouses` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut_manager` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcompany` bigint UNSIGNED NOT NULL,
  `idbranch` bigint UNSIGNED NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `websockets_statistics_entries`
--

CREATE TABLE `websockets_statistics_entries` (
  `id` bigint UNSIGNED NOT NULL,
  `app_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `peak_connection_count` int NOT NULL,
  `websocket_message_count` int NOT NULL,
  `api_message_coun` int NOT NULL,
  `state` tinyint NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branches_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `category_products`
--
ALTER TABLE `category_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_products_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `companies_idcountry_foreign` (`idcountry`),
  ADD KEY `companies_iddistrict_foreign` (`iddistrict`);

--
-- Indices de la tabla `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contracts_idemployee_foreign` (`idemployee`),
  ADD KEY `contracts_type_contract_foreign` (`type_contract`);

--
-- Indices de la tabla `contract_type`
--
ALTER TABLE `contract_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_type_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countries_idmoney_foreign` (`idmoney`);

--
-- Indices de la tabla `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customers_idperson_foreign` (`idperson`);

--
-- Indices de la tabla `detail_employee_user`
--
ALTER TABLE `detail_employee_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_employee_user_idemployee_foreign` (`idemployee`),
  ADD KEY `detail_employee_user_iduser_foreign` (`iduser`);

--
-- Indices de la tabla `detail_modules`
--
ALTER TABLE `detail_modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_modules_idcompany_foreign` (`idcompany`),
  ADD KEY `detail_modules_idmodules_foreign` (`idmodules`);

--
-- Indices de la tabla `detail_money`
--
ALTER TABLE `detail_money`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_money_idcompany_foreign` (`idcompany`),
  ADD KEY `detail_money_idmoney_foreign` (`idmoney`);

--
-- Indices de la tabla `detail_suppliers`
--
ALTER TABLE `detail_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_suppliers_idcompany_foreign` (`idcompany`),
  ADD KEY `detail_suppliers_idsupplier_foreign` (`idsupplier`);

--
-- Indices de la tabla `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `districts_idprovince_foreign` (`idprovince`);

--
-- Indices de la tabla `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employees_idcountry_foreign` (`idcountry`),
  ADD KEY `employees_idcomuna_foreign` (`idcomuna`),
  ADD KEY `employees_type_employee_foreign` (`type_employee`);

--
-- Indices de la tabla `employee_type`
--
ALTER TABLE `employee_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_type_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `lots`
--
ALTER TABLE `lots`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `marks_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modules_idplan_foreign` (`idPlan`);

--
-- Indices de la tabla `money`
--
ALTER TABLE `money`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_method_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `person_type`
--
ALTER TABLE `person_type`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_idmark_foreign` (`idmark`),
  ADD KEY `products_idcategory_foreign` (`idcategory`),
  ADD KEY `products_idsupplier_foreign` (`idsupplier`),
  ADD KEY `products_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provinces_idregion_foreign` (`idregion`);

--
-- Indices de la tabla `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `regions_idcountry_foreign` (`idcountry`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sections_idmodules_foreign` (`idmodules`);

--
-- Indices de la tabla `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`),
  ADD KEY `states_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_idrole_foreign` (`idRole`);

--
-- Indices de la tabla `users_companies`
--
ALTER TABLE `users_companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_companies_iduser_foreign` (`idUser`),
  ADD KEY `users_companies_idcompany_foreign` (`idcompany`);

--
-- Indices de la tabla `warehouses`
--
ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouses_idcompany_foreign` (`idcompany`),
  ADD KEY `warehouses_idbranch_foreign` (`idbranch`);

--
-- Indices de la tabla `websockets_statistics_entries`
--
ALTER TABLE `websockets_statistics_entries`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `branches`
--
ALTER TABLE `branches`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `category_products`
--
ALTER TABLE `category_products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `contract_type`
--
ALTER TABLE `contract_type`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detail_employee_user`
--
ALTER TABLE `detail_employee_user`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detail_modules`
--
ALTER TABLE `detail_modules`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detail_money`
--
ALTER TABLE `detail_money`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detail_suppliers`
--
ALTER TABLE `detail_suppliers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `districts`
--
ALTER TABLE `districts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `employee_type`
--
ALTER TABLE `employee_type`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `lots`
--
ALTER TABLE `lots`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `marks`
--
ALTER TABLE `marks`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `modules`
--
ALTER TABLE `modules`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `money`
--
ALTER TABLE `money`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `payment_method`
--
ALTER TABLE `payment_method`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `person_type`
--
ALTER TABLE `person_type`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `plan`
--
ALTER TABLE `plan`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `provinces`
--
ALTER TABLE `provinces`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `regions`
--
ALTER TABLE `regions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_companies`
--
ALTER TABLE `users_companies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `warehouses`
--
ALTER TABLE `warehouses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `websockets_statistics_entries`
--
ALTER TABLE `websockets_statistics_entries`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `branches`
--
ALTER TABLE `branches`
  ADD CONSTRAINT `branches_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `category_products`
--
ALTER TABLE `category_products`
  ADD CONSTRAINT `category_products_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_idcountry_foreign` FOREIGN KEY (`idcountry`) REFERENCES `countries` (`id`),
  ADD CONSTRAINT `companies_iddistrict_foreign` FOREIGN KEY (`iddistrict`) REFERENCES `districts` (`id`);

--
-- Filtros para la tabla `contracts`
--
ALTER TABLE `contracts`
  ADD CONSTRAINT `contracts_idemployee_foreign` FOREIGN KEY (`idemployee`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `contracts_type_contract_foreign` FOREIGN KEY (`type_contract`) REFERENCES `contract_type` (`id`);

--
-- Filtros para la tabla `contract_type`
--
ALTER TABLE `contract_type`
  ADD CONSTRAINT `contract_type_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `countries`
--
ALTER TABLE `countries`
  ADD CONSTRAINT `countries_idmoney_foreign` FOREIGN KEY (`idmoney`) REFERENCES `money` (`id`);

--
-- Filtros para la tabla `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_idperson_foreign` FOREIGN KEY (`idperson`) REFERENCES `person_type` (`id`);

--
-- Filtros para la tabla `detail_employee_user`
--
ALTER TABLE `detail_employee_user`
  ADD CONSTRAINT `detail_employee_user_idemployee_foreign` FOREIGN KEY (`idemployee`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `detail_employee_user_iduser_foreign` FOREIGN KEY (`iduser`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `detail_modules`
--
ALTER TABLE `detail_modules`
  ADD CONSTRAINT `detail_modules_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `detail_modules_idmodules_foreign` FOREIGN KEY (`idmodules`) REFERENCES `modules` (`id`);

--
-- Filtros para la tabla `detail_money`
--
ALTER TABLE `detail_money`
  ADD CONSTRAINT `detail_money_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `detail_money_idmoney_foreign` FOREIGN KEY (`idmoney`) REFERENCES `money` (`id`);

--
-- Filtros para la tabla `detail_suppliers`
--
ALTER TABLE `detail_suppliers`
  ADD CONSTRAINT `detail_suppliers_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `detail_suppliers_idsupplier_foreign` FOREIGN KEY (`idsupplier`) REFERENCES `suppliers` (`id`);

--
-- Filtros para la tabla `districts`
--
ALTER TABLE `districts`
  ADD CONSTRAINT `districts_idprovince_foreign` FOREIGN KEY (`idprovince`) REFERENCES `provinces` (`id`);

--
-- Filtros para la tabla `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_idcomuna_foreign` FOREIGN KEY (`idcomuna`) REFERENCES `districts` (`id`),
  ADD CONSTRAINT `employees_idcountry_foreign` FOREIGN KEY (`idcountry`) REFERENCES `countries` (`id`),
  ADD CONSTRAINT `employees_type_employee_foreign` FOREIGN KEY (`type_employee`) REFERENCES `employee_type` (`id`);

--
-- Filtros para la tabla `employee_type`
--
ALTER TABLE `employee_type`
  ADD CONSTRAINT `employee_type_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_idplan_foreign` FOREIGN KEY (`idPlan`) REFERENCES `plan` (`id`);

--
-- Filtros para la tabla `payment_method`
--
ALTER TABLE `payment_method`
  ADD CONSTRAINT `payment_method_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_idcategory_foreign` FOREIGN KEY (`idcategory`) REFERENCES `category_products` (`id`),
  ADD CONSTRAINT `products_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `products_idmark_foreign` FOREIGN KEY (`idmark`) REFERENCES `marks` (`id`),
  ADD CONSTRAINT `products_idsupplier_foreign` FOREIGN KEY (`idsupplier`) REFERENCES `suppliers` (`id`);

--
-- Filtros para la tabla `provinces`
--
ALTER TABLE `provinces`
  ADD CONSTRAINT `provinces_idregion_foreign` FOREIGN KEY (`idregion`) REFERENCES `regions` (`id`);

--
-- Filtros para la tabla `regions`
--
ALTER TABLE `regions`
  ADD CONSTRAINT `regions_idcountry_foreign` FOREIGN KEY (`idcountry`) REFERENCES `countries` (`id`);

--
-- Filtros para la tabla `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_idmodules_foreign` FOREIGN KEY (`idmodules`) REFERENCES `modules` (`id`);

--
-- Filtros para la tabla `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_idrole_foreign` FOREIGN KEY (`idRole`) REFERENCES `roles` (`id`);

--
-- Filtros para la tabla `users_companies`
--
ALTER TABLE `users_companies`
  ADD CONSTRAINT `users_companies_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `users_companies_iduser_foreign` FOREIGN KEY (`idUser`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `warehouses`
--
ALTER TABLE `warehouses`
  ADD CONSTRAINT `warehouses_idbranch_foreign` FOREIGN KEY (`idbranch`) REFERENCES `branches` (`id`),
  ADD CONSTRAINT `warehouses_idcompany_foreign` FOREIGN KEY (`idcompany`) REFERENCES `companies` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
