<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FrequentQuery extends Model
{
    use HasFactory;

    protected $table = "frequent_queries";
}
